package com.wallet.ejecucion;

import com.wallet.entidades.Cliente;
import com.wallet.entidades.Cuenta;

public class Main {

	public static void main(String[] args) {
		
		//Crear un cliente con una cuenta existente
		Cuenta billetera1 = new Cuenta(12345, "Juanito", 100);
		Cliente cliente1 = new Cliente(1,"Max",billetera1);
		//mostrar informacion del cliente y su cuenta
		cliente1.saldoDisponible();
		cliente1.realizarDeposito(500);
		cliente1.retirarFondos(200);
		cliente1.cambioMoneda("EUR", 100000);
		cliente1.cambioMoneda("USD", 100000);
		cliente1.mostrarInformacionCliente();
		
	}

}
