package com.wallet.entidades;

import com.wallet.interfaces.AdministracionFondos;
import com.wallet.interfaces.ConversionMoneda;


public class Cliente implements AdministracionFondos, ConversionMoneda{
	
	private long id;
	private String nombre;
	private Cuenta cuenta; // asociación con la clase Cuenta
	
	//constructores:
	public Cliente(long id, String nombre, Cuenta cuenta) {
		this.id = id;
		this.nombre = nombre;
		this.cuenta = cuenta;
	}
	
	public Cliente() {
	}

	//metodos:
	/**
	 * @return este metodo muestra la información del cliente
	 */
	public void mostrarInformacionCliente() {
		System.out.println("Id cliente         : " + id);
		System.out.println("Nombre cliente     : "  + nombre);
		System.out.println("---Datos de la cuenta---" );
		cuenta.mostrarInformacion();
		
	}
	
	
	//getters y setters:
	public long getId() {
		return id;
	}
	
	public void setId(long id) {
		this.id = id;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public Cuenta getCuenta() {
		return cuenta;
	}
	
	public void setCuenta(Cuenta cuenta) {
		this.cuenta = cuenta;
	}
	
	/**
	 * @return este metodo muestra el saldo de la cuenta del cliente seleccionado
	 */
	@Override
	public void saldoDisponible() {
		System.out.println("El saldo de su cuenta es: $" + cuenta.getSaldo());
		
	}
	
	/**
	 * @param cantidad se necesita la cantidad a depositar en la cuenta
	 * @return este metodo retorna el saldo final al realizar un deposito
	 */
	@Override
	public void realizarDeposito(double cantidad) {
		cuenta.setSaldo(cuenta.getSaldo() + cantidad);
		System.out.println("Deposito realizado de forma correcta");
		saldoDisponible();
		
	}

	/**
	 * @param cantidad se necesita la cantidad a retirar de la cuenta
	 * @return el metodo comprueba que el saldo sea mayor o igual a la cantidad y luego muestra el saldo final
	 */
	@Override
	public void retirarFondos(double cantidad) {
		if (cantidad <= cuenta.getSaldo()) {
			cuenta.setSaldo(cuenta.getSaldo() - cantidad);
			System.out.println("Usted retiro de forma exitosa");
			saldoDisponible();
		} else {
			System.out.println("El saldo que desea retirar excede la cantidad actual en su cuenta, intente con otro monto...");
		}
		
	}
	
	/**
	 * @param moneda este metodo necesita el tipo de moneda en String ("EUR" para euro o "USD" para dolar)
	 * @param cantidad este metodo necesita la cantidad que se desea cambiar en numero double
	 */
	@Override
	public void cambioMoneda(String moneda, double cantidad) {
		switch(moneda) {
		case "EUR" :
			cantidad = (cantidad / 1015.28);
			System.out.println("El total convertido es: " + cantidad + " Euros");
			break;
		case "USD" :
			cantidad = (cantidad / 943.25);
			System.out.println("El total convertido es: " + cantidad + " Dolares");
			break;
		}
			
		
	}
	
	

}
