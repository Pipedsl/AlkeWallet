package com.wallet.interfaces;

public interface AdministracionFondos {
	
	/**
	 * No necesita agregar parametros
	 */
	public void saldoDisponible();
	/**
	 * 
	 * @param cantidad ingresar como double la cantidad a depositar
	 */
	public void realizarDeposito(double cantidad);
	/**
	 * 
	 * @param cantidad ingresar como double la cantidad a retirar
	 */
	public void retirarFondos(double cantidad);

}
