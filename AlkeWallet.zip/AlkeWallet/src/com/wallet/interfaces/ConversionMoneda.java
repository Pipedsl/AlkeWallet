package com.wallet.interfaces;

public interface ConversionMoneda {
	/**
	 * 
	 * @param moneda ingresar como String el tipo de moneda 
	 * @param cantidad ingresar como double la cantidad a convertir
	 */
	public void cambioMoneda(String moneda, double cantidad);
	
}
