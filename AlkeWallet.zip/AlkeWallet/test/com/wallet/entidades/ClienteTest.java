package com.wallet.entidades;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ClienteTest {

	private Cuenta cuenta;
	private Cliente cliente;
	
	@BeforeEach
	public void configuracion() {
		cuenta = new Cuenta(12345,"Juanito", 1000.0);
		cliente = new Cliente(1,"Max", cuenta);
	}
	
	@Test
	void testSaldoDisponible() {
		assertEquals(1000, cuenta.getSaldo(), "El saldo debe ser el igual al de la configuración");
	}
	
    @Test
    void testRealizarDeposito() {
        cliente.realizarDeposito(500.0);
        assertEquals(1500.0, cuenta.getSaldo(), "El saldo después del depósito debe ser 1500");
    }

    @Test
    void testRetirarFondos() {
        cliente.retirarFondos(200.0);
        assertEquals(800.0, cuenta.getSaldo(), "El saldo después de retirar 200 debe ser 800");
    }
    



}
